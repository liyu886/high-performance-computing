/*
 * Complier:gcc -g -o 4_Monte-carlo 4_Monte-carlo.c -lpthread 
 * Run: ./4_Monte-carlo <number of threads> <number of points>
 */
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include"my_rand.h"


int thread_count;
int number_toss;

long long number_in_shadow = 0;

long long quotient = 0;
long long remainder = 0;

pthread_mutex_t mymutex;

void* thread_fun(void* thread);

int main(int arg, char** argv){

    pthread_mutex_init(&mymutex, NULL);
    long thread;
    thread_count = strtol(argv[1], NULL, 10);
    number_toss = strtol(argv[2], NULL, 10);

    quotient = number_toss / thread_count;
    remainder = number_toss % thread_count;

    pthread_t* thread_handles = (pthread_t*)malloc(sizeof(pthread_t) * thread_count);

    for(thread = 0; thread < thread_count; thread++){
        pthread_create(&thread_handles[thread], NULL, thread_fun, (void*)thread);
    }

    for(thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }

    free(thread_handles);
    pthread_mutex_destroy(&mymutex);

    double area = (number_in_shadow * 1.0) / (number_toss * 1.0);
    printf("The area of the shadowy part is %lf.\n", area);

}

//store the number of points whitch are in or out shadow
void* thread_fun(void* thread){
    long myrank = (long)thread;
    long long mywork;
    long long local_in_shadow = 0;
    unsigned seed = 1, speed;
    speed = my_rand(&seed);

    if((long long)myrank < remainder){
        mywork = quotient + 1;
    }else{
        mywork = quotient;
    }

    long long index;
    double x, y;
    for(index = 0; index < mywork; index++){
        x = my_drand(&speed);
        y = my_drand(&speed);

        if(y <= x * x){
            local_in_shadow++;
        }
    }

    pthread_mutex_lock(&mymutex);

    number_in_shadow += local_in_shadow;

    pthread_mutex_unlock(&mymutex);

    return NULL;

}