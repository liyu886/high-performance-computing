#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include"timer.h"
#define range 50

void print(int* matrix, int row, int col);
void initmatrix(int *A, int row, int col);
void gemm(int *matrix_ans, int *matrixA, int *matrixB, int m, int n, int k);



int main(int argc, char **argv){
    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);

    double start, finish;
    double serial_time;
    int comm_sz, my_rank;
    int *A, *B, *C;//存放矩阵A、B、C
    int *buf_A, *buf_B, *buf_C;//每个进程需要存储的矩阵块
    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    //分配内存
    //将矩阵A分为comm_sz块，每块有A_line行
    int A_line = m / comm_sz;
    buf_A = (int*)malloc(A_line * n * sizeof(int));
    buf_B = (int*)malloc(n * k * sizeof(int));
    buf_C = (int*)malloc(A_line * k * sizeof(int));

    if(my_rank == 0){
        //随机生成矩阵
        A = (int*)malloc(m * n * sizeof(int));
        B = (int*)malloc(n * k * sizeof(int));
        C = (int*)malloc(m * k * sizeof(int));
        initmatrix(A, m, n);
        initmatrix(B, n, k);

        //开始计时
        start = MPI_Wtime();


        //分发
        for(int i = 1; i < comm_sz; i++){
            MPI_Send(A + (i - 1) * A_line * n, A_line * n, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(B, n * k, MPI_INT, i, 1, MPI_COMM_WORLD);
        }
        

        //接收各个进程得到答案,并存入矩阵C中
        for(int i = 1; i < comm_sz; i++){
            MPI_Recv(buf_C, A_line * k, MPI_INT, i, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for(int j = 0; j < A_line; j++){
                for(int a = 0; a < k; a++){
                    C[((i - 1) * A_line + j) * k + a] = buf_C[j * k + a];
                }
            }
        }


        int finish_row = A_line * (comm_sz - 1);
        if(finish_row < m){//如果有剩余矩阵没有被计算，交给0号进程
            gemm(C + finish_row * k, A + finish_row * n, B, m - finish_row, n, k);
        }

        finish = MPI_Wtime();
	/*
        printf("matrix A: \n");
        print(A, m, n);
        printf("matrix B: \n");
        print(B, n, k);
        printf("matrix C: \n");
        print(C, m, k);
        */
        
        switch(m){
            case 128: serial_time = 0.007717; break;
            case 256: serial_time = 0.070070; break;
            case 512: serial_time = 0.796828; break;
            case 1024: serial_time = 14.185418; break;
            case 2048: serial_time = 190.541541; break;
        }

        double speedup = (double)serial_time / (finish - start) ;
        double efficiency = speedup / comm_sz;
        printf("Runtime is %lf s by parallel.\n", finish - start);
        printf("Runtime is %lf s by serial.\n", serial_time);
        printf("Seedup is %lf.\n", speedup);
        printf("Efficiency is %lf.\n", efficiency);
	
        free(A);
        free(B);
        free(C);


    }else{
        //其他进程，接受数据存储在buf中，并计算
        MPI_Recv(buf_A, A_line * n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(buf_B, n * k, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        gemm(buf_C, buf_A, buf_B, A_line, n, k);

        //将结果发送给0号进程
        MPI_Send(buf_C, A_line * k, MPI_INT, 0, 2, MPI_COMM_WORLD);

    }
   
    free(buf_A);
    free(buf_B);
    free(buf_C);

    MPI_Finalize();
    

    return 0;
}


void print(int* matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", matrix[i * col + j]);
        }
        printf("\n");
    }
}

void gemm(int *matrix_ans, int *matrixA, int *matrixB, int m, int n, int k){

    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += matrixA[i * n + a] * matrixB[a * k + j];
            }
            matrix_ans[i * k + j] = temp;
        }
    }
}

void initmatrix(int *A, int row, int col){
    for(int i = 0 ; i < row * col; i++){
        A[i] = rand() % range;
    }
}
