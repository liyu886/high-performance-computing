/******************************************
 * Compile:
 * gcc -g -o 2_sum1 2_sum1.c -lpthread
 * Run:       
 * ./2_sum <number of threads>
 
 * Each thread only reads one integer at a time.
 ******************************************/

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include"timer.h"

#define range 5
#define size 10000

int global_index = 0;
int array[size];
int thread_count;
int global_sum = 0;
pthread_mutex_t mutex;

void init(int* array);
void print(int* array);
void* thread_sum(void* rank);


int main(int arg, char** argv){

    double start, finish;

    init(array);

    GET_TIME(start);
    pthread_mutex_init(&mutex, NULL);

    long thread;
    pthread_t* thread_handles;

    thread_count = strtol(argv[1], NULL, 10);
    thread_handles = malloc(thread_count * sizeof(pthread_t));

    int quotient = size / thread_count;

    for(thread = 0; thread < thread_count; thread++){
        for(int i = 0; i < quotient; i++)
        pthread_create(&thread_handles[thread], NULL, thread_sum, (void*)thread);
    }

    for(thread = 0; thread < thread_count; thread++){

        for(int i = 0; i < quotient; i++)
        pthread_join(thread_handles[thread], NULL);
 
    }

    pthread_mutex_destroy(&mutex);
    free(thread_handles);
    GET_TIME(finish);
/*
    printf("The random array is:\n");
    print(array);
    printf("\n");
*/
    //printf("Each thread only reads one integer at a time. Sum is %d by parallel, and run time is %lfs.\n", global_sum, finish - start);
    printf("Sum is %d by parallel, and run time is %lfs.\n", global_sum, finish - start);

    int sum = 0;
    for(int i = 0; i < size; i++){
        sum += array[i];
    }
    printf("serial answer is %d\n", sum);
    return 0;

}

void init(int* array){
    srand(time(0));
    for(int i = 0; i < size; i++){
        array[i] = (int)rand() % range;
    }
}

//获取a数组的下一个未加元素
void* thread_sum(void* rank){

    //int myrank = (int)rank;
    pthread_mutex_lock(&mutex);
    //printf("my rank is %d, visting index is %d\n", myrank, global_index);
    global_sum += array[global_index];
    global_index++;
    pthread_mutex_unlock(&mutex);

}

void print(int* array){
    int count = 0;
    for(int i = 0; i < size; i++){
        if(count < 15){
            printf("%d ", array[i]);
            count++;
        }else{
            printf("%d\n", array[i]);
            count = 0;
        }
    }
}

