   /******************************************
 * Compile:
 * gcc -g -o 1_gemm 1_gemm.c -lpthread
 * Run:       
 * ./1_gemm <number of threads>
 ******************************************/

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include"timer.h"
#define range 5
//global var
int m, n, k;//矩阵规模
int *matrixA, *matrixB, *matrixC;
int thread_count;//线程个数

//functions
void print(int* matrix, int row, int col);
void initmatrix(int *A, int row, int col);
void* gemm(void* rank);

int main(int arg, char* argv[]){
    printf("Please enter 3 integers(512~2048):\n");
    scanf("%d", &m);
    scanf("%d", &n);
    scanf("%d", &k);

    matrixA = (int*)malloc(m * n * sizeof(int));
    matrixB = (int*)malloc(n * k * sizeof(int));
    matrixC = (int*)malloc(m * k * sizeof(int));

    initmatrix(matrixA, m,n);
    initmatrix(matrixB, n, k);

    double start, finish;

    GET_TIME(start);

    long thread;
    pthread_t *thread_handles;
    thread_count = strtol(argv[1], NULL, 10);
    thread_handles = malloc(thread_count * sizeof(pthread_t));

    for(thread = 0; thread < thread_count; thread++){
        pthread_create(&thread_handles[thread], NULL, gemm, (void*)thread);
    }
    for(thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }

    free(thread_handles);

    GET_TIME(finish);
/*
    printf("random matrixA is:\n");
    print(matrixA, m, n);
    printf("random matrixB is:\n");
    print(matrixB, n, k);
    printf("the result matrix is:\n");
    print(matrixC, m, k);
*/
    printf("Run time is: %lfs\n", finish - start);

    free(matrixA);
    free(matrixB);
    free(matrixC);
}


void print(int* matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", matrix[i * col + j]);
        }
        printf("\n");
    }
}

void initmatrix(int *A, int row, int col){
    for(int i = 0 ; i < row * col; i++){
        A[i] = rand() % range;
    }
}

void* gemm(void* rank){
    int my_rank = (long)rank;
    int quotient = m / thread_count;
    int remainder = m % thread_count;
    int my_first_row, my_last_row;//本线程要计算的起始行和结束行
    int my_local_n;//本线程要计算的行数

    //如果不能平均分配（有余数）
    //对于rank小于剩余行数的线程来说，就多计算一行
    if(my_rank < remainder){
        my_local_n = quotient + 1;
        my_first_row = my_rank * my_local_n;
        my_last_row = my_first_row + my_local_n;
    }else{
        my_local_n = quotient;
        my_first_row = my_rank * my_local_n + remainder;
        my_last_row = my_first_row + my_local_n;
    }

    for(int i = my_first_row; i < my_last_row; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += matrixA[i * n + a] * matrixB[a * k + j];
            }
            matrixC[i * k + j] = temp;
        }
    }
    return NULL;

}
