/******************************************
 * Compile:
 * gcc -g -o 3_root 3_root.c -lpthread -lm
 * Run:       
 * ./3_root
 * Solving the root of a quadratic equation of one variable
 ******************************************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<pthread.h>
#include<unistd.h>

//global variables 
double a, b, c;
int thread_count = 3;
int count = 0;
double delta = -1;
double molecule1, molecule2;
double root1, root2;

pthread_mutex_t mymutex;
pthread_cond_t mycond;

void* fun1(void* rank);
void* fun2(void* rank);
void* fun3(void* rank);

int main(){

    printf("Please enter three numbers: a, b, c.\n");
    scanf("%lf", &a);
    scanf("%lf", &b);
    scanf("%lf", &c);

    pthread_mutex_init(&mymutex, NULL);
    pthread_cond_init(&mycond, NULL);

    long thread;
    pthread_t* thread_handles = (pthread_t*)malloc(thread_count * sizeof(pthread_t));

    pthread_create(&thread_handles[0], NULL, fun1, (void*)0);
    pthread_create(&thread_handles[1], NULL, fun2, (void*)1);
    pthread_create(&thread_handles[2], NULL, fun3, (void*)2);

    count++;
    sleep(0.1);
    pthread_cond_signal(&mycond);

    for (thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }


    pthread_mutex_destroy(&mymutex);
    pthread_cond_destroy(&mycond);
    free(thread_handles);

    if(delta >= 0){
    	if(root1 != root2)
            printf("root1 is %lf, root2 is %lf.\n", root1, root2);
        else 
            printf("root is %lf.\n", root1);
        	
    }

}

void* fun1(void* rank){
    pthread_mutex_lock(&mymutex);
    printf("Rank %ld get mutex lock.\n", (long)rank);
    
    while(count < 1){
        pthread_cond_wait(&mycond, &mymutex);
    }
    
    delta = b*b-4*a*c;
    if(delta < 0){
        printf("No solution! Rank %ld is over!\n", (long)rank);
        exit(0);
    }
    count++;
    pthread_cond_signal(&mycond);
    printf("Rank %ld signal condition variables.\n", (long)rank);
    pthread_mutex_unlock(&mymutex);
    printf("Rank %ld release mutex lock.\n", (long)rank);
    
}


void* fun2(void* rank){
    
    pthread_mutex_lock(&mymutex);
    printf("Rank %ld get mutex lock.\n", (long)rank);
    //
    
    while(count < 2){
        pthread_cond_wait(&mycond, &mymutex);
    }

    molecule1 = -b + sqrt(delta);
    molecule2 = -b - sqrt(delta);
    count++;

    pthread_cond_signal(&mycond);
    printf("Rank %ld signal condition variables.\n", (long)rank);
    pthread_mutex_unlock(&mymutex);
    printf("Rank %ld release mutex lock.\n", (long)rank);
}


void* fun3(void* rank){
    
    pthread_mutex_lock(&mymutex);
    printf("Rank %ld get mutex lock.\n", (long)rank);

    while(count < 3){
        pthread_cond_wait(&mycond, &mymutex);
    }

    root1 = molecule1 / (2*a);
    root2 = molecule2 / (2*a);
    count++;

    pthread_cond_signal(&mycond);
    printf("Rank %ld signal condition variables.\n", (long)rank);
    pthread_mutex_unlock(&mymutex);
    printf("Rank %ld release mutex lock.\n", (long)rank);
    printf("Threads are over!\n");

}
