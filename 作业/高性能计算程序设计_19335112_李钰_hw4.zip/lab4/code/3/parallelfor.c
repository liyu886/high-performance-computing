#include"parallelfor.h"


void parallel_for(int start, int end, int increment,void*(*functor)(void*), void *arg, int num_threads){
    pthread_t* thread_handles = (pthread_t*)malloc(sizeof(pthread_t) * num_threads);
    for_index* para = (for_index*)malloc(sizeof(for_index) * num_threads);
    int quotient = (end - start) / num_threads;
    int remainder = (end - start) % num_threads;
    int mywork;

    for(int thread = 0; thread < num_threads; thread++){
        if(thread < remainder){
            mywork = quotient + 1;
            para[thread].mystart = thread * mywork + start;
        }else{
            mywork = quotient;
            para[thread].mystart = start + thread * mywork + remainder;
        }
        para[thread].myend = para[thread].mystart + mywork;
        para[thread].myincrement = increment;
        para[thread].args = arg;
        pthread_create(&thread_handles[thread], NULL, functor, (void*)(para+thread));        
    }
    

    for(int thread = 0; thread < num_threads; thread++){
        pthread_join(thread_handles[thread], NULL);
    }

    free(thread_handles);
    free(para);

}

