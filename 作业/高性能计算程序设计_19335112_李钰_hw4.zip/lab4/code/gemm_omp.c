/******************************************
 * Compile:
 * gcc -g -o gemm_omp gemm_omp.c -fopenmp
 * Run:       
 * ./gemm_omp <thread_count>
 * matrix multiplication gemm OpenMP
 ******************************************/
#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
#include"timer.h"
#define range 5

//functions
void print(int** matrix, int row, int col);
void initmatrix(int **A, int row, int col);


int main(int argc, char* argv[]){
    int thread_count = strtol(argv[1], NULL, 10);
    int m, n, k;
    printf("Please enter 3 integers:\n");
    scanf("%d%d%d", &m, &n, &k);

    int** A, **B, **C;
    A = (int**)malloc(m * sizeof(int*));
    B = (int**)malloc(n * sizeof(int*));
    C = (int**)malloc(m * sizeof(int*));

    for(int i = 0; i < m; i++){
        A[i] = (int*)malloc(n * sizeof(int));
    }
    for(int i = 0; i < n; i++){
        B[i] = (int*)malloc(k * sizeof(int));
    }
    for(int i = 0; i < m; i++){
        C[i] = (int*)malloc(k * sizeof(int));
    }
    initmatrix(A, m, n);
    initmatrix(B, n, k);
/*
    printf("A:\n");
    print(A, m, n);
    printf("B:\n");
    print(B, n, k);
*/
    double start, end;
    GET_TIME(start);
    #pragma omp parallel for num_threads(thread_count) 
    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += A[i][a] * B[a][j];
            }
            C[i][j] = temp;
        }
        
    }
    GET_TIME(end);

    printf("Run time is: %lfs.\n", end-start);
    //printf("C:\n");
    //print(C, m, k);
}


void print(int** matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%4d", matrix[i][j]);
        }
        printf("\n");
    }
}

void initmatrix(int **A, int row, int col){
    for(int i = 0 ; i < row; i++){
        for(int j = 0; j < col; j++){
            A[i][j] = rand() % range;
        }
    }
}

