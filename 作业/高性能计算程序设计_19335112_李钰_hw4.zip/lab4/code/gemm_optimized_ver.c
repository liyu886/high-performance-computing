/******************************************
 * Compile:
 * gcc -g -o gemm_optimized_ver gemm_optimized_ver.c -fopenmp
 * Run:       
 * ./gemm_optimized_ver.c <thread_count>
 * matrix multiplication gemm OpenMP
 ******************************************/
#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
#include"timer.h"
#define range 50

int m, n, k;
int** A, **B, **C;
int thread_count;
//functions
void print(int** matrix, int row, int col);
void initmatrix(int **A, int row, int col);
void default_sche();
void static_sche();
void dynamic_sche();


int main(int argc, char* argv[]){

    thread_count = strtol(argv[1], NULL, 10);
    printf("Please enter 3 integers:\n");
    scanf("%d%d%d", &m, &n, &k);

    
    A = (int**)malloc(m * sizeof(int*));
    B = (int**)malloc(n * sizeof(int*));
    C = (int**)malloc(m * sizeof(int*));

    for(int i = 0; i < m; i++){
        A[i] = (int*)malloc(n * sizeof(int));
    }
    for(int i = 0; i < n; i++){
        B[i] = (int*)malloc(k * sizeof(int));
    }
    for(int i = 0; i < m; i++){
        C[i] = (int*)malloc(k * sizeof(int));
    }
    initmatrix(A, m, n);
    initmatrix(B, n, k);
/*
    printf("A:\n");
    print(A, m, n);
    printf("B:\n");
    print(B, n, k);
*/
    double start, end;
    GET_TIME(start);
    default_sche();
    GET_TIME(end);
    printf("Run time is: %lfs by default schedule.\n", end-start);
//    printf("C:\n");
//    print(C, m, k);

    GET_TIME(start);
    static_sche();
    GET_TIME(end);
    printf("Run time is: %lfs by static schedule.\n", end-start);
//    printf("C:\n");
//    print(C, m, k);

    GET_TIME(start);
    dynamic_sche();
    GET_TIME(end);
    printf("Run time is: %lfs by dynamic schedule.\n", end-start);
//    printf("C:\n");
//    print(C, m, k);
}


void print(int** matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%4d", matrix[i][j]);
        }
        printf("\n");
    }
}

void initmatrix(int **A, int row, int col){
    for(int i = 0 ; i < row; i++){
        for(int j = 0; j < col; j++){
            A[i][j] = rand() % range;
        }
    }
}

void default_sche(){
    #pragma omp parallel for num_threads(thread_count) 
    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += A[i][a] * B[a][j];
            }
            C[i][j] = temp;
        }
    }
}


void static_sche(){
    #pragma omp parallel for num_threads(thread_count) \
    schedule(static, 1)
    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += A[i][a] * B[a][j];
            }
            C[i][j] = temp;
        }
    }
}
void dynamic_sche(){
    #pragma omp parallel for num_threads(thread_count) \
    schedule(dynamic, 1)
    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += A[i][a] * B[a][j];
            }
            C[i][j] = temp;
        }
    }
}

