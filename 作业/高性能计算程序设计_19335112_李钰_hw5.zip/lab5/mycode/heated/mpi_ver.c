/*
 * 0号进程也用local_u
 * 只传每个进程需要的
 *
*/


# include <stdlib.h>
# include <stdio.h>
# include <math.h>
# include "timer.h"
# include <omp.h>
# include <mpi.h>

double mean = 0;

int main ( int argc, char *argv[] ){
    int M = 500;
    int N = 500;

    double** u;
    double** w;

    double** local_u;
    double** local_w;
    double epsilon = 0.001;
    double diff;
    double my_diff;
    double start, finish;
    
    int iterations = 0;
    int iterations_print = 1;

    int comm_sz;
    int my_rank;

    
    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    int work = (M - 2) / comm_sz;
    int bufsize = (work + comm_sz + 2) * N;
    //printf("bufsize is %ld\n", bufsize * sizeof(double));
    double* buf = (double* )malloc(sizeof(double) * bufsize);

    local_u = (double** )malloc(sizeof(double* ) * (work + comm_sz + 2));
    local_w = (double** )malloc(sizeof(double* ) * (work + comm_sz + 2));
    for(int i = 0; i < work + comm_sz + 2; i++){
        for(int j = 0; j < N; j++){
            local_u[i] = (double* )malloc(sizeof(double) * N);
            local_w[i] = (double* )malloc(sizeof(double) * N);
        }
    }

    if(my_rank == 0){
        
        w=(double**) malloc (sizeof(double*)*M);
        u=(double**) malloc (sizeof(double*)*M);
        for(int i = 0;i < M; i++){
            w[i]=(double*) malloc(sizeof(double)*N);
            u[i]=(double*) malloc(sizeof(double)*N);
        }

        printf ( "\n" );
        printf ( "HEATED_PLATE_OPENMP\n" );
        printf ( "  C/OpenMP version\n" );
        printf ( "  A program to solve for the steady state temperature distribution\n" );
        printf ( "  over a rectangular plate.\n" );
        printf ( "\n" );
        printf ( "  Spatial grid of %d by %d points.\n", M, N );
        printf ( "  The iteration will be repeated until the change is <= %e\n", epsilon ); 
        printf ( "  Number of processors available = %d\n", omp_get_num_procs ( ) );
        printf ( "  Number of threads =              %d\n", omp_get_max_threads ( ) );

        //threads
        int i, j;
        #pragma omp parallel shared ( w ) private ( i, j )
        {
            #pragma omp for
            for ( i = 1; i < M - 1; i++ ){
                w[i][0] = 100.0;
                w[i][N - 1] = 100.0;
                u[i][0] = 100.0;
                u[i][N - 1] = 100.0;
                if(i <= work + 1){
                    local_u[i][0] = 100.0;
                    local_u[i][N - 1] = 100.0;
                }
                
            }

            #pragma omp for
            for ( j = 0; j < N; j++ ){
                w[M - 1][j] = 100.0;
                w[0][j] = 0.0;
                u[M - 1][j] = 100.0;
                u[0][j] = 0.0;

                local_u[0][j] = 0.0;
            }
        }
        
        mean = 0;
        //#pragma omp for reduction ( + : mean )
        for ( i = 1; i < M - 1; i++ ){
            mean = mean + w[i][0] + w[i][N-1];
        }
        //#pragma omp for reduction ( + : mean )
        for ( j = 0; j < N; j++ ){
            mean = mean + w[M-1][j] + w[0][j];
        }

        mean = mean / ( double ) ( 2 * M + 2 * N - 4 );
        printf ( "\n" );
        printf ( "  MEAN = %f\n", mean );

        int master_end = 1 + work - 1;

        #pragma omp parallel shared ( mean, w ) private ( i, j )
        {
            #pragma omp for
            for ( i = 1; i < M - 1; i++ ){
                for ( j = 1; j < N - 1; j++ ){
                    w[i][j] = mean;
                    u[i][j] = w[i][j];
                    if(i <= master_end + 1){
                        local_u[i][j] = mean;
                    }
                }
            }
        }

        
        printf ( "\n" );
        printf ( " Iteration  Change\n" );
        printf ( "\n" );

        
        GET_TIME(start);
        for(int i = 1; i < comm_sz; i++){
            int begin = 1 + i * work;
            int end = (i == comm_sz - 1) ? M - 2 : begin + work - 1;//suan
            int pos = 0;
            
            for(int j = begin - 1; j <= end + 1; j++){
                MPI_Pack(u[j], N, MPI_DOUBLE, buf, bufsize * sizeof(double), &pos, MPI_COMM_WORLD);
            }

            //printf("POS: %d\n", pos);
            MPI_Send(buf, pos, MPI_PACKED, i, 0, MPI_COMM_WORLD);
            //printf("send rank %d begin %d, end %d\n", my_rank, begin, end);
        }
    }else{
        int begin = 1 + my_rank * work;
        int end = (my_rank == comm_sz - 1) ? M - 2 : begin + work - 1;
        int myrow = end - begin + 1 + 2;

        MPI_Recv(buf, bufsize * sizeof(double), MPI_PACKED, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int pos = 0;
        
        for(int i = 0; i < myrow; i++){
            MPI_Unpack(buf, bufsize * sizeof(double), &pos, local_u[i], N, MPI_DOUBLE, MPI_COMM_WORLD);
        }
    }

    
    diff = epsilon;

    while(epsilon <= diff){
        //pack and send

        int begin = 1 + my_rank * work;
        int end = (my_rank == comm_sz - 1) ? M - 2 : begin + work - 1;
        int myrow = end - begin + 1 + 2;

        #pragma omp parallel for
        for(int i = 1; i < myrow -1; i++){
            for(int j = 1; j < N - 1; j++){
                local_w[i][j] = (local_u[i - 1][j] + local_u[i + 1][j] + local_u[i][j - 1] + local_u[i][j + 1]) / 4.0;
            }
            local_w[i][0] = local_w[i][N - 1] = 100;
        }

        my_diff = 0;
        #pragma omp parallel for
        for(int i = 1; i < myrow - 1; i++){
            for(int j = 1; j < N -1; j++){
                if(my_diff < fabs(local_w[i][j] - local_u[i][j])){
                    my_diff = fabs(local_w[i][j] - local_u[i][j]);
                }
                local_u[i][j] = local_w[i][j];
            }
            local_u[i][0] = local_u[i][N - 1] = 100.0;
        }

        MPI_Reduce(&my_diff, &diff, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        
        if(my_rank == 0){

            int pos = 0;
            MPI_Recv(buf, bufsize * sizeof(double), MPI_PACKED, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Unpack(buf, bufsize * sizeof(double), &pos, local_u[work + 1], N, MPI_DOUBLE, MPI_COMM_WORLD);
           
            pos = 0;
            MPI_Pack(local_u[work - 1], N, MPI_DOUBLE, buf, bufsize * sizeof(double), &pos, MPI_COMM_WORLD);
            MPI_Send(buf, pos, MPI_PACKED, 1, 3, MPI_COMM_WORLD);

            //printf("-----------------------------\n");

            iterations++;
            if ( iterations == iterations_print ){
                printf ( "  %8d  %f\n", iterations, diff );
                iterations_print = 2 * iterations_print;
            }

        }else{

            int pos = 0;
            MPI_Pack(local_u[1], N, MPI_DOUBLE, buf, sizeof(double) * bufsize, &pos, MPI_COMM_WORLD);
            MPI_Send(buf, pos, MPI_PACKED, my_rank - 1, 1, MPI_COMM_WORLD);

            if(my_rank != comm_sz - 1){
                pos = 0;
                MPI_Pack(local_u[myrow - 2], N, MPI_DOUBLE, buf, sizeof(double) * bufsize, &pos, MPI_COMM_WORLD);
                MPI_Send(buf, pos, MPI_PACKED, my_rank + 1, 3, MPI_COMM_WORLD);

            }
            MPI_Recv(buf, bufsize * sizeof(double), MPI_PACKED, my_rank - 1, 3, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            pos = 0;
            MPI_Unpack(buf, bufsize * sizeof(double), &pos, local_u[0], N, MPI_DOUBLE, MPI_COMM_WORLD);
            if(my_rank != comm_sz - 1){
                MPI_Recv(buf, bufsize * sizeof(double), MPI_PACKED, my_rank + 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                pos = 0;
                MPI_Unpack(buf, bufsize * sizeof(double), &pos, local_u[myrow - 1], N, MPI_DOUBLE, MPI_COMM_WORLD);
            }

        }

    }


    if(my_rank == 0){
        GET_TIME(finish);
        free(w);
        free(u);
        printf ( "\n" );
        printf ( "  %8d  %f\n", iterations, diff );
        printf ( "\n" );
        printf ( "  Error tolerance achieved.\n" );
        printf ( "  Wallclock time = %lfs\n", finish - start);
        /*
        Terminate.
        */
        printf ( "\n" );
        printf ( "HEATED_PLATE_OPENMP:\n" );
        printf ( "  Normal end of execution.\n" );
    }
    
    free(local_u);
    free(local_w);
    free(buf);
    MPI_Finalize();
      return 0;



}
