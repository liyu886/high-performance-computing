# include <stdlib.h>
# include <stdio.h>
# include <math.h>
# include <time.h>
# include <float.h>
# include <omp.h>
# include "timer.h"
# include "parallelfor.h"

pthread_mutex_t error_mutex;
int thread_count;

double error;
double *x;
double *y;
double *z;
double *w;

double z0;
double z1;
int n;
double sgn;

typedef struct two_args{
    void* arg1;
    void* arg2;
}two_args;

typedef struct five_args{
    int mj;
    double* a;
    double* b;
    double* c;
    double* d;
}five_args;


void ccopy ( int n, double x[], double y[] );
void* copy_functor(void* args);
void cfft2 ( int n, double x[], double y[], double w[], double sgn );
void cfft2_p ( int n, double x[], double y[], double w[], double sgn );
void cffti ( int n, double w[] );
void cffti_p ( int n, double w[] );

double ggl ( double *ds );
void step ( int n, int mj, double a[], double b[], double c[], double d[], double w[], double sgn );
void step_p ( int n, int mj, double a[], double b[], double c[], double d[], double w[], double sgn );
void timestamp ( );

void* functor2(void* arg);
void* error_functor(void* arg);
void* functor4(void* arg);
void* functor5(void* arg);
void* functor6(void* arg);

/******************************************************************************/

int main(int argc, char* argv[]){
    thread_count = strtol(argv[1], NULL, 10);
    pthread_mutex_init(&error_mutex, NULL);

    double ctime;
    double ctime1;
    double ctime2;
    
    int first;
    double flops;
    double fnm1;
    int i;
    int icase;
    int it;
    int ln2;
    double mflops;
    int n;
    int nits = 10000;
    
    double start, finish;
  
    static double seed;

    timestamp ( );
    printf ( "\n" );
    printf ( "FFT_PARALLEL\n" );
    printf ( "  C version\n" );
    printf ( "\n" );
    printf ( "  Demonstrate an implementation of the Fast Fourier Transform\n" );
    printf ( "  of a complex data vector.\n" );
    
    printf ( "  Number of processors available = %d\n", omp_get_num_procs ( ) );
    printf ( "  Number of threads =              %d\n", thread_count );

    printf ( "\n" );
    printf ( "  Accuracy check:\n" );
    printf ( "\n" );
    printf ( "    FFT ( FFT ( X(1:N) ) ) == N * X(1:N)\n" );
    printf ( "\n" );
    printf ( "             N      NITS    Error         Time          Time/Call     MFLOPS\n" );
    printf ( "\n" );

    seed  = 331.0;
    n = 1;

    GET_TIME(start);
    for ( ln2 = 1; ln2 <= 21; ln2++ ){
        n = 2 * n;
        int parallel = (n > thread_count) ? 1 : 0;

        w = ( double * ) malloc (     n * sizeof ( double ) );
        x = ( double * ) malloc ( 2 * n * sizeof ( double ) );
        y = ( double * ) malloc ( 2 * n * sizeof ( double ) );
        z = ( double * ) malloc ( 2 * n * sizeof ( double ) );


        if(parallel){
            first = 1;

            for ( icase = 0; icase < 2; icase++ ){
                if ( first ){

                    for ( i = 0; i < 2 * n; i = i + 2 )
                    {
                        z0 = ggl ( &seed );
                        z1 = ggl ( &seed );
                        x[i] = z0;
                        z[i] = z0;
                        x[i+1] = z1;
                        z[i+1] = z1;
                    }
                    
                } 
                else{
                    parallel_for(0, 2 * n, 2, functor2, NULL, thread_count);
                }

                //cffti_p ( n, w );
                cffti ( n, w );

                if ( first ){
                    
                    sgn = + 1.0;
                    cfft2 ( n, x, y, w, sgn );
                    sgn = - 1.0;
                    cfft2 ( n, y, x, w, sgn );

                    fnm1 = 1.0 / ( double ) n;
                    error = 0.0;

                    parallel_for(0, 2 * n, 2, error_functor, &fnm1, thread_count);

                    error = sqrt ( fnm1 * error );
                    printf ( "  %12d  %8d  %12e", n, nits, error);

                    first = 0;
                }
                else{

                    GET_TIME(ctime1);
                    //parallel_for(0, nits, 1, functor4, NULL, thread_count);
                    for ( it = 0; it < nits; it++ ){

                        sgn = + 1.0;
                        cfft2_p ( n, x, y, w, sgn );
                        sgn = - 1.0;
                        cfft2_p ( n, y, x, w, sgn );
                    }
                    GET_TIME(ctime2);
                    ctime = ctime2 - ctime1;

                    flops = 2.0 * ( double ) nits * ( 5.0 * ( double ) n * ( double ) ln2 );

                    mflops = flops / 1.0E+06 / ctime;

                    printf ( "  %12e  %12e  %12f\n", ctime, ctime / ( double ) ( 2 * nits ), mflops );
                }
            }
        }else{
            first = 1;

            for ( icase = 0; icase < 2; icase++ ){
                if ( first ){
                    for ( i = 0; i < 2 * n; i = i + 2 )
                    {
                      z0 = ggl ( &seed );
                      z1 = ggl ( &seed );
                      x[i] = z0;
                      z[i] = z0;
                      x[i+1] = z1;
                      z[i+1] = z1;
                    }
                } 
                else{
                    for ( i = 0; i < 2 * n; i = i + 2 )
                    {
                      z0 = 0.0;              /* real part of array */
                      z1 = 0.0;              /* imaginary part of array */
                      x[i] = z0;
                      z[i] = z0;           /* copy of initial real data */
                      x[i+1] = z1;
                      z[i+1] = z1;         /* copy of initial imag. data */
                    }
                }

                cffti ( n, w );

                if ( first ){

                    sgn = + 1.0;
                    cfft2 ( n, x, y, w, sgn );
                    sgn = - 1.0;
                    cfft2 ( n, y, x, w, sgn );

                    fnm1 = 1.0 / ( double ) n;
                    error = 0.0;
                    for ( i = 0; i < 2 * n; i = i + 2 )
                    {
                      error = error 
                      + pow ( z[i]   - fnm1 * x[i], 2 )
                      + pow ( z[i+1] - fnm1 * x[i+1], 2 );
                    }
                    error = sqrt ( fnm1 * error );
                    printf ( "  %12d  %8d  %12e", n, nits, error );
                    first = 0;
                }
                else{

                    GET_TIME(ctime1);
                    for ( it = 0; it < nits; it++ ){

                        sgn = + 1.0;
                        cfft2 ( n, x, y, w, sgn );
                        sgn = - 1.0;
                        cfft2 ( n, y, x, w, sgn );
                    }
                    GET_TIME(ctime2);
                    ctime = ctime2 - ctime1;

                    flops = 2.0 * ( double ) nits * ( 5.0 * ( double ) n * ( double ) ln2 );

                    mflops = flops / 1.0E+06 / ctime;

                    printf ( "  %12e  %12e  %12f\n", ctime, ctime / ( double ) ( 2 * nits ), mflops );
                }
            }  
        }
        if ( ( ln2 % 4 ) == 0 ) {
            nits = nits / 10;
        }
        if ( nits < 1 ) {
            nits = 1;
        }

        free ( w );
        free ( x );
        free ( y );
        free ( z );
    }
    GET_TIME(finish);
    printf ( "\n" );
    printf ( "FFT_SERIAL:\n" );
    printf ( "  Normal end of execution.\n" );
    printf ( "\n" );
    timestamp ( );
    pthread_mutex_destroy(&error_mutex);
    printf("Run time is %lfs.\n", finish-start);

    return 0;
}
/******************************************************************************/

void ccopy ( int n, double x[], double y[] )
{
  int i;

  for ( i = 0; i < n; i++ )
  {
    y[i*2+0] = x[i*2+0];
    y[i*2+1] = x[i*2+1];
   }
  return;
}
/******************************************************************************/
void* copy_functor(void* args){
    for_index* index = (for_index*)args;
    double* a = ((two_args*)index->args)->arg1;
    double* b = ((two_args*)index->args)->arg2;

    for(int i = index->mystart; i < index->myend; i += index->myincrement){
        a[i*2+0] = b[i*2+0];
        a[i*2+1] = b[i*2+1];
    }
    return NULL;
}


void cfft2 ( int n, double x[], double y[], double w[], double sgn )
{
    int j;
    int m;
    int mj;
    int tgle;

    m = ( int ) ( log ( ( double ) n ) / log ( 1.99 ) );
    mj   = 1;

    tgle = 1;
    step ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );

    if ( n == 2 )
    {
      return;
    }

    for ( j = 0; j < m - 2; j++ )
    {
      mj = mj * 2;
      if ( tgle )
      {
        step ( n, mj, &y[0*2+0], &y[(n/2)*2+0], &x[0*2+0], &x[mj*2+0], w, sgn );
        tgle = 0;
      }
      else
      {
        step ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );
        tgle = 1;
      }
    }
  /* 
    Last pass through data: move Y to X if needed.
  */
    if ( tgle ) 
    {
      ccopy ( n, y, x );
    }

    mj = n / 2;
    step ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );

    return;
}

void cfft2_p ( int n, double x[], double y[], double w[], double sgn )
{
    int j;
    int m;
    int mj;
    int tgle;

    m = ( int ) ( log ( ( double ) n ) / log ( 1.99 ) );
    mj   = 1;

    tgle = 1;
    step_p ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );

    if ( n == 2 )
    {
      return;
    }

    for ( j = 0; j < m - 2; j++ )
    {
      mj = mj * 2;
      if ( tgle )
      {
        step_p ( n, mj, &y[0*2+0], &y[(n/2)*2+0], &x[0*2+0], &x[mj*2+0], w, sgn );
        tgle = 0;
      }
      else
      {
        step_p ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );
        tgle = 1;
      }
    }
  /* 
    Last pass through data: move Y to X if needed.
  */
    if ( tgle ) 
    {
        // two_args temp;
        // temp.arg1 = x;
        // temp.arg2 = y;
        // parallel_for(0, n, 1, copy_functor, &temp, thread_count); 
        ccopy ( n, y, x );
    }

    mj = n / 2;
    step_p ( n, mj, &x[0*2+0], &x[(n/2)*2+0], &y[0*2+0], &y[mj*2+0], w, sgn );

    return;
}
/******************************************************************************/

void cffti ( int n, double w[] ){
    double arg;
    double aw;
    int i;
    int n2;
    const double pi = 3.141592653589793;

    n2 = n / 2;
    aw = 2.0 * pi / ( ( double ) n );

    for ( i = 0; i < n2; i++ ){

        arg = aw * ( ( double ) i );
        w[i*2+0] = cos ( arg );
        w[i*2+1] = sin ( arg );
    }
    
    return;
}



double ggl ( double *seed ){
  double d2 = 0.2147483647e10;
  double t;
  double value;

  t = *seed;
  t = fmod ( 16807.0 * t, d2 );
  *seed = t;
  value = ( t - 1.0 ) / ( d2 - 1.0 );

  return value;
}
/******************************************************************************/

void step ( int n, int mj, double a[], double b[], double c[],
  double d[], double w[], double sgn ){
    double ambr;
    double ambu;
    int j;
    int ja;
    int jb;
    int jc;
    int jd;
    int jw;
    int k;
    int lj;
    int mj2;
    double wjw[2];

    mj2 = 2 * mj;
    lj  = n / mj2;
  
    for ( j = 0; j < lj; j++ ){
        jw = j * mj;
        ja  = jw;
        jb  = ja;
        jc  = j * mj2;
        jd  = jc;

        wjw[0] = w[jw*2+0]; 
        wjw[1] = w[jw*2+1];

        if ( sgn < 0.0 ) 
        {
          wjw[1] = - wjw[1];
        }

        for ( k = 0; k < mj; k++ )
        {
            c[(jc+k)*2+0] = a[(ja+k)*2+0] + b[(jb+k)*2+0];
            c[(jc+k)*2+1] = a[(ja+k)*2+1] + b[(jb+k)*2+1];

            ambr = a[(ja+k)*2+0] - b[(jb+k)*2+0];
            ambu = a[(ja+k)*2+1] - b[(jb+k)*2+1];

            d[(jd+k)*2+0] = wjw[0] * ambr - wjw[1] * ambu;
            d[(jd+k)*2+1] = wjw[1] * ambr + wjw[0] * ambu;
        }
    }
    
    
    return;
}


void step_p ( int n, int mj, double a[], double b[], double c[],
  double d[], double w[], double sgn ){
    double ambr;
    double ambu;
    int j;
    int ja;
    int jb;
    int jc;
    int jd;
    int jw;
    int k;
    int lj;
    int mj2;
    double wjw[2];

    mj2 = 2 * mj;
    lj  = n / mj2;

    int parallel = (lj > 2 * thread_count) ? 1 : 0;

    if(parallel){
        five_args temp;
        temp.mj = mj;
        temp.a = a;
        temp.b = b;
        temp.c = c;
        temp.d = d;
       
        parallel_for(0, lj, 1, functor6, &temp, thread_count); 
    }else{
        for ( j = 0; j < lj; j++ ){
            jw = j * mj;
            ja  = jw;
            jb  = ja;
            jc  = j * mj2;
            jd  = jc;

            wjw[0] = w[jw*2+0]; 
            wjw[1] = w[jw*2+1];

            if ( sgn < 0.0 ) 
            {
              wjw[1] = - wjw[1];
            }

            for ( k = 0; k < mj; k++ )
            {
                c[(jc+k)*2+0] = a[(ja+k)*2+0] + b[(jb+k)*2+0];
                c[(jc+k)*2+1] = a[(ja+k)*2+1] + b[(jb+k)*2+1];

                ambr = a[(ja+k)*2+0] - b[(jb+k)*2+0];
                ambu = a[(ja+k)*2+1] - b[(jb+k)*2+1];

                d[(jd+k)*2+0] = wjw[0] * ambr - wjw[1] * ambu;
                d[(jd+k)*2+1] = wjw[1] * ambr + wjw[0] * ambu;
            }
        }
    }
    
    return;
}
/******************************************************************************/

void timestamp ( ){
# define TIME_SIZE 40

  static char time_buffer[TIME_SIZE];
  const struct tm *tm;
  time_t now;

  now = time ( NULL );
  tm = localtime ( &now );

  strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm );

  printf ( "%s\n", time_buffer );

  return;
# undef TIME_SIZE
}


void* functor2(void* arg){
    for_index* index = (for_index*)arg;
    for ( int i = index->mystart; i < index->myend; i = i + index->myincrement ){
        z0 = 0.0;              /* real part of array */
        z1 = 0.0;              /* imaginary part of array */
        x[i] = z0;
        z[i] = z0;           /* copy of initial real data */
        x[i+1] = z1;
        z[i+1] = z1;         /* copy of initial imag. data */
    }
    return NULL;
}

void* error_functor(void* arg){
    for_index* index = (for_index*)arg;
    double local_error = 0.0;
    for ( int i = index->mystart; i < index->myend; i = i + index->myincrement ){
        local_error = local_error
        + pow ( (z[i]   - (*(double*)(index->args)) * x[i]), 2 )
        + pow ( (z[i+1] - (*(double*)(index->args)) * x[i+1]), 2 );
        
    }
    pthread_mutex_lock(&error_mutex);
    error += local_error;
    pthread_mutex_unlock(&error_mutex);

    return NULL;
}

void* functor4(void* arg){
    for_index* index = (for_index*)arg;

    for ( int i = index->mystart; i < index->myend; i = i + index->myincrement ){
        sgn = + 1.0;
        cfft2 ( n, x, y, w, sgn );
        sgn = - 1.0;
        cfft2 ( n, y, x, w, sgn );
    }
    return NULL;
}

void cffti_p ( int n, double w[] ){
    // double arg;
    // double aw;
    // int i;
    int n2;
    //const double pi = 3.141592653589793;

    n2 = n / 2;
    //aw = 2.0 * pi / ( ( double ) n );
    // int parallel = (n2 > thread_count) ? 1 : 0;

    // if(parallel){
       parallel_for(0, n2, 1, functor5, NULL, thread_count); 
    // }else{
    //     for ( i = 0; i < n2; i++ ){

    //         arg = aw * ( ( double ) i );
    //         w[i*2+0] = cos ( arg );
    //         w[i*2+1] = sin ( arg );
    //     }
    // }
    
    return;
}


void* functor5(void* arg){

    for_index* index = (for_index*)arg;

    double args;
    double aw;
    const double pi = 3.141592653589793;
    aw = 2.0 * pi / ( ( double ) n );

    for ( int i = index->mystart; i < index->myend; i = i + index->myincrement ){

        args = aw * ( ( double ) i );
        w[i*2+0] = cos ( args );
        w[i*2+1] = sin ( args );
    }
    return NULL;
}

void* functor6(void* arg){

    double ambr;
    double ambu;

    int ja;
    int jb;
    int jc;
    int jd;
    int jw;
    
    int mj2;
    double wjw[2];

    
    for_index* index = (for_index*)arg;
    int mj = ((five_args*)(index->args))->mj;
    double* a = ((five_args*)(index->args))->a; 
    double* b = ((five_args*)(index->args))->b; 
    double* c = ((five_args*)(index->args))->c; 
    double* d = ((five_args*)(index->args))->d;

    mj2 = 2 * mj;
    

    for ( int j = index->mystart; j < index->myend; j = j + index->myincrement ){
        jw = j * mj;
        ja  = jw;
        jb  = ja;
        jc  = j * mj2;
        jd  = jc;

        wjw[0] = w[jw*2+0]; 
        wjw[1] = w[jw*2+1];

        if ( sgn < 0.0 ) 
        {
          wjw[1] = - wjw[1];
        }

        for ( int k = 0; k < mj; k++ )
        {
            c[(jc+k)*2+0] = a[(ja+k)*2+0] + b[(jb+k)*2+0];
            c[(jc+k)*2+1] = a[(ja+k)*2+1] + b[(jb+k)*2+1];

            ambr = a[(ja+k)*2+0] - b[(jb+k)*2+0];
            ambu = a[(ja+k)*2+1] - b[(jb+k)*2+1];

            d[(jd+k)*2+0] = wjw[0] * ambr - wjw[1] * ambu;
            d[(jd+k)*2+1] = wjw[1] * ambr + wjw[0] * ambu;
        }
    }
    return NULL;
}
