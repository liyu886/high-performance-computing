#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

typedef struct for_index{
    int mystart;
    int myend;
    int myincrement;
    void* args;
}for_index;

void parallel_for(int start, int end, int increment,void*(*functor)(void*), void *arg, int num_threads);
