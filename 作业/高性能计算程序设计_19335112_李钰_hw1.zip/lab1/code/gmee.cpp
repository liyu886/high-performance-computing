#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<vector>
#include<fstream>
#include"timer.h"

#define range 100
#define flag 32
using namespace std;
void software_ver(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

void print(vector<vector<int> > n);

//分解
void separate(vector<vector <int> >matrix, vector<vector <int> >& A11, vector<vector <int> >&A12, vector<vector <int> >&A21, vector<vector <int> >&A22);

//create matrix_S
//矩阵减法
//矩阵加法
void sum(vector<vector <int> >&sum, vector<vector <int> > a, vector<vector <int> >b);
void reduce(vector<vector <int> >&reduce, vector<vector <int> > a, vector<vector <int> >b);

int strassen (vector<vector <int> >&producer, vector<vector <int> > a, vector<vector <int> >b);

int main(){
    int n;
    cin >> n;
    double start, finish;
    ofstream fp;
    fp.open("result.txt");



    int seed = time(0);
    srand(seed);

    vector<vector<int> > matrixA(n, vector<int>(n, 0));
    vector<vector<int> > matrixB(n, vector<int>(n, 0));
    vector<vector<int> > matrix_ans1(n, vector<int>(n, 0));
    vector<vector<int> > matrix_ans2(n, vector<int>(n, 0));

    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            matrixA[i][j] = rand() % range;
        }
    }

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            matrixB[i][j] = rand() % range;
        }
    }


    //cout << "random " << m << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixA[i][j] << " ";
            fp << matrixA[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    
    //cout << "random " << n << "*" << k << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixB[i][j] << " ";
            fp << matrixB[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    GET_TIME(start)
    gemm(matrix_ans2, matrixA, matrixB);
    GET_TIME(finish);
    fp << "result2" << endl;
    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans2[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    fp.close();
    cout << "gmee: " << endl;
    cout << n << " * " << n << " matrixA times " << n << " * " << n << " matrixB " << endl;
    cout << "cost time:" << finish - start << endl;

    
   
    

}


void print(vector<vector<int> > n){
    for(int i = 0; i < n.size(); i++){
        for(int j = 0; j < n[i].size(); j++){
            cout << n[i][j] << " ";
        }
        cout << endl;
    }
}

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB){
    int n = matrix_ans.size();
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            for(int a = 0; a < n; a++){
                matrix_ans[i][j] += matrixA[i][a] * matrixB[a][j];
            }
        }
    }
}

