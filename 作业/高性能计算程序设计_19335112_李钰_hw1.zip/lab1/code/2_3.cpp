#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<vector>
#include<fstream>

#include<bits/stdc++.h>
#include<cstdlib>
#include"mkl.h"
#include"timer.h"



#define range 10000
#define flag 32
using namespace std;
void software_ver(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

void print(vector<vector<int> > n);

void transMatrix(vector<vector<int>>&A,double*A1, int M, int N);

int main(){
    int m, n, k;
    cin >> m >> n >> k;

    double start, finish;
    double *matrixA1, *matrixB1, *matrixC1;
    double alpha=1.0,beta = 0.0;
    ofstream fp;
    fp.open("result.txt");



    int seed = time(0);
    srand(seed);

    vector<vector<int> > matrixA(m, vector<int>(n, 0));
    vector<vector<int> > matrixB(n, vector<int>(k, 0));
    vector<vector<int> > matrix_ans1(m, vector<int>(k, 0));
    vector<vector<int> > matrix_ans2(m, vector<int>(k, 0));

    matrixA1 = (double*)mkl_malloc(m * n *sizeof(double), 64);
    matrixB1 = (double*)mkl_malloc(k * n *sizeof(double), 64);
    matrixC1 = (double*)mkl_malloc(m * k *sizeof(double), 64);
    

    int x = 0;
    fp << "random " << n << "*" << n << " matrix " << endl;
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            matrixA[i][j] = rand() % range;
            fp << matrixA[i][j] << " ";
            matrixA1[x] = (double)matrixA[i][j];
            x++;
        }
           fp << endl;
    }


    fp << "random " << n << "*" << k << " matrix " << endl;
    x = 0;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < k; j++){
            matrixB[i][j] = rand() % range;
            fp << matrixB[i][j] << " ";
            matrixB1[x] = (double)matrixB[i][j];
            x++;
        }
        fp << endl;
    }

    for(int i = 0; i < (m * k); i++){
        matrixC1[i] = (double)1.0-1.0;
    }


    //start = clock();
    GET_TIME(start);
    gemm(matrix_ans1, matrixA, matrixB);
    //finish = clock();
    GET_TIME(finish);

    fp << "result1" << endl;
    
    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans1[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    cout << "gmee: " << endl;
    cout << m << " * " << n << " matrixA times " << n << " * " << k << " matrixB " << endl;
    cout << setprecision(6) << "cost time:" << finish - start << endl;

    //cout << "result" << endl;
    
    //start = clock();
    GET_TIME(start);

    software_ver(matrix_ans2, matrixA, matrixB);

    //finish = clock();
    GET_TIME(finish);
    fp << "result2" << endl;

    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans2[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    cout << "software version:" << endl;
    cout << m << " * " << n << " matrixA times " << n << " * " << k << " matrixB " << endl;
    cout << setprecision(6) << "cost time:" << finish - start << endl;


    //start = clock();
    GET_TIME(start);
	cblas_dgemm(CblasRowMajor,CblasNoTrans,CblasNoTrans,m, n, k, alpha, matrixA1, n, matrixB1, k, beta, matrixC1, k);
	//finish = clock();
    GET_TIME(finish);
    fp << "result3" << endl;
    int f = k;
    for(int i = 0; i < m * k; i++){
        fp << matrixC1[i] << " ";
        f--;
        if(f == 0){
            fp << endl;
            f = k;
        }
    }

    cout << "MKL:" << endl;
    cout << m << " * " << n << " matrixA times " << n << " * " << k << " matrixB " << endl;
    cout << setprecision(6) << "cost time:" << finish - start << endl;

    fp.close();
    return 0; 
    

}



void print(vector<vector<int> > n){
    for(int i = 0; i < n.size(); i++){
        for(int j = 0; j < n[i].size(); j++){
            cout << n[i][j] << " ";
        }
        cout << endl;
    }
}

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB){
    int n = matrixB.size();
    int m = matrixA.size();
    int k = matrixB[0].size();
    
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            for(int a = 0; a < k; a++){
                matrix_ans[i][j] += matrixA[i][a] * matrixB[a][j];
            }
        }
    }
}

void software_ver(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB){
    int m = matrixA.size();
    int n = matrixB.size();
    int k = matrixB[0].size();

    for(int i = 0; i < m; i += 4){
        for(int j = 0; j < k; j += 4){
            for (int a = 0; a < n; a++) {
                int tempa1  = matrixA[i + 0][a];
                    int tempa2  = matrixA[i + 1][a];
                    int tempa3  = matrixA[i + 2][a];
                    int tempa4  = matrixA[i + 3][a];

                    int tempb1 = matrixB[a][j + 0];
                    int tempb2 = matrixB[a][j + 1];
                    int tempb3 = matrixB[a][j + 2];
                    int tempb4 = matrixB[a][j + 3];
                    

                    matrix_ans[i + 0][j + 0] += tempa1 * tempb1;
                    matrix_ans[i + 0][j + 1] += tempa1 * tempb2;
                    matrix_ans[i + 0][j + 2] += tempa1 * tempb3;
                    matrix_ans[i + 0][j + 3] += tempa1 * tempb4;

                    matrix_ans[i + 1][j + 0] += tempa2 * tempb1;
                    matrix_ans[i + 1][j + 1] += tempa2 * tempb2;
                    matrix_ans[i + 1][j + 2] += tempa2 * tempb3;
                    matrix_ans[i + 1][j + 3] += tempa2 * tempb4;

                    matrix_ans[i + 2][j + 0] += tempa3 * tempb1;
                    matrix_ans[i + 2][j + 1] += tempa3 * tempb2;
                    matrix_ans[i + 2][j + 2] += tempa3 * tempb3;
                    matrix_ans[i + 2][j + 3] += tempa3 * tempb4;

                    matrix_ans[i + 3][j + 0] += tempa4 * tempb1;
                    matrix_ans[i + 3][j + 1] += tempa4 * tempb2;
                    matrix_ans[i + 3][j + 2] += tempa4 * tempb3;
                    matrix_ans[i + 3][j + 3] += tempa4 * tempb4;
            }
        }
    }
}

