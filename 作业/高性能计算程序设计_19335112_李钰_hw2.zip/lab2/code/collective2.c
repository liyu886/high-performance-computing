#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>

#define range 50

void print(int* matrix, int row, int col);
void initmatrix(int *A, int row, int col);
void gemm(int *matrix_ans, int *matrixA, int *matrixB, int m, int n, int k);
void Build_mpi_type(int *A, MPI_Datatype *matrix_mpi_t, int m, int n);

int main(int argc, char **argv){
    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);

    double start, finish;
    int comm_sz, my_rank;
    int *A, *B, *C;//存放矩阵A、B、C
    int *buf_A, *buf_C;
    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    //分配内存
    //将矩阵A分为comm_sz块，每块有A_line行
    int A_line = m / comm_sz;

    buf_A = (int*)malloc(A_line * n * sizeof(int));
    B = (int*)malloc(n * k * sizeof(int));
    buf_C = (int*)malloc(A_line * k * sizeof(int));

    MPI_Datatype matrixB_mpi_t;

    
    if(my_rank == 0){
        A = (int*)malloc(m * n * sizeof(int));
        C = (int*)malloc(m * k * sizeof(int));
        //随机生成矩阵
        initmatrix(A, m, n);
        initmatrix(B, n, k);
    }
    

    Build_mpi_type(B, &matrixB_mpi_t, n, k);

    MPI_Barrier(MPI_COMM_WORLD);
    //开始计时
    start = MPI_Wtime();

    MPI_Scatter(A, A_line * n, MPI_INT, buf_A, A_line * n, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(B, 1, matrixB_mpi_t, 0, MPI_COMM_WORLD);
    //MPI_Bcast(B, n * k, MPI_INT, 0, MPI_COMM_WORLD);

    gemm(buf_C, buf_A, B, A_line, n, k);

    MPI_Barrier(MPI_COMM_WORLD);
    //聚集到0号进程
    MPI_Gather(buf_C, A_line * k, MPI_INT, C, A_line * k, MPI_INT, 0, MPI_COMM_WORLD);

    if(my_rank == 0){
        int finish_row = A_line * (comm_sz - 1);
        if(finish_row < m){//如果有剩余矩阵没有被计算，交给0号进程
            gemm(C + finish_row * k, A + finish_row * n, B, m - finish_row, n, k);
        }

        finish = MPI_Wtime();
        /*
        printf("matrix A: \n");
        print(A, m, n);
        printf("matrix B: \n");
        print(B, n, k);
        printf("matrix C: \n");
        print(C, m, k);
        */
        printf("Runtime is %lf s\n", finish - start);
	
        free(A);
        free(C);
    }
   
    free(buf_A);
    free(B);
    free(buf_C);

    MPI_Type_free(&matrixB_mpi_t);

    MPI_Finalize();

    return 0;
}


void print(int* matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", matrix[i * col + j]);
        }
        printf("\n");
    }
}

void gemm(int *matrix_ans, int *matrixA, int *matrixB, int m, int n, int k){

    for(int i = 0; i < m; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += matrixA[i * n + a] * matrixB[a * k + j];
            }
            matrix_ans[i * k + j] = temp;
        }
    }
}

void initmatrix(int *A, int row, int col){
    for(int i = 0 ; i < row * col; i++){
        A[i] = rand() % range;
    }
}
/*
void Build_mpi_type(int *B, MPI_Datatype *matrixB_mpi_t, int k, int n){
    
    int array_of_blocklengths[k * n];
    MPI_Datatype array_of_types[k * n];
    for(int i = 0; i < k * n; i++){
        array_of_blocklengths[i] = 1;
        array_of_types[i] = MPI_INT;
    }


    MPI_Aint a_addr, b_addr;
    MPI_Aint array_of_displacements[k * n];

    MPI_Get_address(&B[0], &a_addr);
    MPI_Get_address(&B[1], &b_addr);
    array_of_displacements[0] = 0;
    array_of_displacements[1] = b_addr - a_addr;
    for(int i = 2; i < k * n; i++){
        MPI_Aint temp;
        MPI_Get_address(&B[i], &temp);
        array_of_displacements[i] = temp - a_addr;
    }

    MPI_Type_create_struct(k * n, array_of_blocklengths, array_of_displacements, array_of_types, matrixB_mpi_t);
    MPI_Type_commit(matrixB_mpi_t); 

}
*/

void Build_mpi_type(int *B, MPI_Datatype *matrixB_mpi_t, int k, int n){
    
    int array_of_blocklengths[1] = {n * k};
    MPI_Datatype array_of_types[1] = {MPI_INT};
    MPI_Aint array_of_displacements[1] = {0};

    MPI_Type_create_struct(1, array_of_blocklengths, array_of_displacements, array_of_types, matrixB_mpi_t);
    MPI_Type_commit(matrixB_mpi_t); 

}
