#include"matrix_multiply.h"
#include<stdlib.h>

double** gemm(double** matrixA, double** matrixB, int M, int N, int K) {   //通用矩阵乘法
	double **matrix = (double**)malloc(sizeof(double*) * M);
	for (int i = 0;i<M;++i)
		matrix[i]=(double *)malloc(sizeof(double) * K);
	for (int i = 0; i < M; i++){
		for (int j = 0; j < K; j++){
			matrix[i][j] = 0;
			for (int l = 0; l < N; l++){
				matrix[i][j] += matrixA[i][l] * matrixB[l][j];
			}
		}
	}
	return matrix;
}
