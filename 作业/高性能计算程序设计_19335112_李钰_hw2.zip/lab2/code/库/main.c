#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"matrix_multiply.h"

double** initMatrix(int row, int col) {  //初始化矩阵
	double **temp = (double**)malloc(sizeof(double*) * row);
	for (int i = 0;i < row; i++){
		temp[i] = (double *)malloc(sizeof(double) * col);
	}
		

	for(int i = 0; i < row; i++){
		for (int j = 0; j < col; j++){
			temp[i][j] = (double)rand() / (double)(RAND_MAX)*100;
		}
	}
	return temp;
}

void print(double** mat, int row, int col){  //输出矩阵
	for(int i = 0; i < row; i++){
		for(int j = 0;j < col; j++){
			printf("%lf ",mat[i][j]);
		}
		printf("\n");
	}
	
}


int main(){
	int M, N, K;

	printf("Please enter 3 integers :\n");
	scanf("%d",&M);
	scanf("%d",&N);
	scanf("%d",&K);
	
	double** matrixA = initMatrix(M,N);
	double** matrixB = initMatrix(N,K);
    
	clock_t begin, finish;
	begin = clock();
	double** matrixC = gemm(matrixA, matrixB, M, N, K);
	finish = clock();
	double time=(double)(finish - begin) / CLOCKS_PER_SEC;
    printf("matrix A:\n");
	print(matrixA,M,N);
	printf("matrix B:\n");
	print(matrixB,N,K);
	printf("matrix C:\n");
	print(matrixC,M,K);
	printf("time of gemm: %f s\n",time);
    
	return 0;
}
