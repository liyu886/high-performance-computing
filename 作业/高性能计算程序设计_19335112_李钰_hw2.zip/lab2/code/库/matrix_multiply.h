#ifndef matrix_multiply_h
#define matrix_multiply_h
double** gemm(double** matrixA, double** matrixB, int M, int N, int K);
#endif 
